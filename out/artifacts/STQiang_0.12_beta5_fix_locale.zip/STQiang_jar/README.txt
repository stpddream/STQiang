STQiang 0.12 beta5 No Midterm Edition
=========================================================================
Please do NOT distrubute. Thanks!


Prerequisite to use this program, read CAREFULLY before starting to use:

1. You have to know Chinese. else you won't be able to finish reading this. Take Chinese course and ask Panda for help, he is a Chinese tutor. Don't ask Cornie.

2.使用说明：

a. 安装jre 1.7. http://www.java.com/en/download/index.jsp
b. 解压STQiang.zip
c. 运行STQiang.jar （一般双击就可以打开，linux 的话用jar 命令，用Linux的孩子自己找）
d. 查找event_id
    登录haverticket, 点击有意的event链接，地址栏会出现如下形式url https://go.haverford.edu/tickets/?mode=show&event_id=10198
    看到event_id=没。然也然也孺子可教！
    （本工具暂不支持直接浏览event，会不会写看造化了，暂觉无甚必要）
e. 输入event_id和姓名
f. 单击Gei Wo Qiang. (Turn off sleep of your operating system! Connect to internet cable if possible)
g. 到头便睡，大梦谁先觉，醒来票已得。慷慨死犹勇，除非有bug。
h. 周三前去拿票。

Disclaimer
1. 尚是测试版。出bug的几率和去dc发现非常难吃的几率差不多。
2. 本工具不对因为没有起来抢票睡过头者负责。


*For now, this tool is for SEPTA passes on Monday only. 

ST
